package lista.Infos;

public enum editora {
    ACTIVISION("Activision"),
    ATARI("Atari"),
    BETHESDA("Bethesda Softworks"),
    ELETRONIC("Electronic Arts"),
    MICROSOFT("Microsoft Game Studios"),
    NITENDO("Nintendo"),
    SEGA("Sega"),
    SONY("Sony Computer Entertainment"),
    SQUARE("SquareSoft"),
    TAKE("Take-Two Interactive"),
    UBISOFT("Ubisoft");

    private String descricao;

    editora(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
