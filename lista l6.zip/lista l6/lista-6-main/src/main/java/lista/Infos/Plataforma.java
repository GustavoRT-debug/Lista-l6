package lista.Infos;

public enum Plataforma {
    PS2("PS2"),
    P2600("2600"),
    PC("PC"),
    XB("XB"),
    Wii("Wii"),
    GBA("GBA"),
    P3DS("3DS"),
    N64("N64"),
    PS("PS"),
    X360("X360"),
    PS4("PS4"),
    PS3("PS3"),
    NES("NES"),
    GB("GB"),
    DS("DS"),
    SNES("SNES"),

    PSP("PSP");

    private String descricao;

    Plataforma(String descricao){
        this.descricao = descricao;
    }

    public String getDescricao(){
        return descricao;
    }
}
