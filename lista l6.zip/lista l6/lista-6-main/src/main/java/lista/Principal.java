package lista;

import lista.novo.CSV;

//lendo o arquivo
public class Principal {
    public static void main(String[] args) {
        CSV.readDataLineByLine("vendas-games.csv");
    }
}
