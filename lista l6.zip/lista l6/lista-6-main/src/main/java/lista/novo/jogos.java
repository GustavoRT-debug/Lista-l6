package lista;

//lombok=Sua vantagem é evitar uma repetição de código "clichê", como a criação de obtém e conjuntos para todos os atributos, métodos equals e hashCode, toString, Construtores entre outros. Dessa forma, o código fica mais limpo e claro.
import lombok.Data;

@Data
public class jogos {
    private String publisher;
    private double na_sales;
    private double eu_sales;
    private int rank;
    private double jp_sales;
    private String platform;
    private int year;
    private double other_sales;
    private String name;
    private String genre;

    private double global_sales;

    public jogos(String name,int year,String publisher,String platform,double other_sales,int rank, double eu_sales,String genre, double na_sales, double jp_sales, double global_sales) {
        this.jp_sales = jp_sales;
        this.rank = rank;
        this.year = year;
        this.genre = genre;
        this.name = name;
        this.na_sales = na_sales;
        this.eu_sales = eu_sales;
        this.platform = platform;
        this.publisher = publisher;
        this.other_sales = other_sales;
        this.global_sales = global_sales;
    }
}

