# Lista 6
Resolução da L6
